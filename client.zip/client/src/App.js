import "./App.css";
import { Route, Routes } from "react-router-dom";
// import Join from "./component/join/Join";
import Chat from "./component/chat/Chat";

function App() {
  return (
    <div className="App">
      <Routes>
        {/* <Route exact path="/" Component={Join} /> */}
        <Route exact path="/" Component={Chat} />
        {/* <Route path="/chat" Component={Chat} /> */}
      </Routes>
    </div>
  );
}

export default App;
