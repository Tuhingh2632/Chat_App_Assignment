import React, { useEffect, useState } from "react";
import socketIO from "socket.io-client";
import sendLogo from "../../images/send.png";
import closeIcon from "../../images/closeIcon.png";
import Message from "../message/Message.js";
import ReactScrollToBottom from "react-scroll-to-bottom";
import "./Chat.css";
import emoji from "../../images/happy.png";

import data from "@emoji-mart/data";
import Picker from "@emoji-mart/react";

const ENDPOINT = "http://localhost:4500/";
const user_list = ["Alan", "Bob", "Carol", "Dean", "Elin"];
let socket = socketIO(ENDPOINT, { transports: ["websocket"] });
const Chat = () => {
  const [id, setid] = useState("");
  const [messages, setMessages] = useState([]);
  const [showPicker, setShowPicker] = useState(false);
  const [inputValue, setInputValue] = useState("");
  let user = user_list[Math.floor(Math.random() * user_list.length)];
  const send = () => {
    const message = document.getElementById("chatInput").value;
    socket.emit("message", { message, id });
    setInputValue("");
  };

  useEffect(() => {
    socket.on("connect", () => {
      setid(socket.id);
    });

    socket.emit("joined", { user });
    socket.on("welcome", (data) => {
      console.log(data.user, data.message);
    });

    socket.on("userjoined", (data) => {
      console.log(data.user, data.message);
    });

    socket.on("leave", (data) => {
      console.log(data.user, data.message);
    });

    return () => {
      socket.emit("disconnected");
      socket.off();
    };
  }, []);

  useEffect(() => {
    socket.on("sendMessage", (data) => {
      setMessages([...messages, data]);
      console.log(data.user, data.message, data.id);
    });
    return () => {
      socket.off();
    };
  }, [messages]);

  return (
    <div className="chatPage">
      <div className="chatContainer">
        <div className="header">
          <h2>Happy Chating...</h2>
          <a href="/">
            {" "}
            <img src={closeIcon} alt="Close" />
          </a>
        </div>
        <ReactScrollToBottom className="chatBox">
          {messages.map((item, i) => (
            <Message
              user={item.user}
              message={item.message}
              classs={item.id === id ? "right" : "left"}
            />
          ))}
        </ReactScrollToBottom>
        <div className="inputBox">
          <input
            onKeyPress={(event) => (event.key === "Enter" ? send() : null)}
            type="text"
            id="chatInput"
            value={inputValue}
            onChange={(e) => {
              e.preventDefault();
              setInputValue(e.target.value);
            }}
          />
          <img
            src={emoji}
            className="emoji"
            onClick={() => setShowPicker(!showPicker)}
            alt="epic"
          />
          <div className={showPicker ? "d-block" : "d-none"}>
            {showPicker && (
              <Picker
                data={data}
                previewPosition="none"
                onEmojiSelect={(e) => {
                  setInputValue(inputValue + e.native);
                  console.log(inputValue + e.native);
                  setShowPicker(!showPicker);
                }}
                className="emojiPicker"
              />
            )}
          </div>
          <button onClick={send} className="sendBtn">
            <img src={sendLogo} alt="Send" />
          </button>
        </div>
      </div>
    </div>
  );
};

export default Chat;
