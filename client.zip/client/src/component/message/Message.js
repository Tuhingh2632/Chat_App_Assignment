import React, { useState } from "react";
import "./Message.css";
import linkLogo from "../../images/png-transparent-like-thumb-social-vote-favorite-love-social-reaction-and-emoji-icon-thumbnail.png";

const Message = ({ user, message, classs }) => {
  const [count, setCount] = useState(1);
  const handleClick = () => {
    setCount(count + 1);
    console.log(count);
  };
  if (message) {
    return (
      <div className={`messageBox ${classs}`}>
        {`${user}: ${message}`}
        <img
          className="likeImage"
          src={linkLogo}
          alt="like"
          onClick={handleClick}
        />
        <h6 className="likeCount">{count}</h6>
      </div>
    );
  }
};

export default Message;
